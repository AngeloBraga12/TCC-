<!DOCTYPE html>

<html lang="pt-br">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" type="png" href="/YouJob/img/icon-page.png">
    <link rel="stylesheet" href="/YouJob/CSS/geral.css">
    <link rel="stylesheet" href="/YouJob/CSS/home.css" />
    <link rel="stylesheet" href="/YouJob/CSS/cadastro.css" />
    <title>
    <?php
        $arquivo = basename($_SERVER['SCRIPT_FILENAME']);
        $titulo = str_replace(".php", "", $arquivo);

        if(file_exists('index.php')){
            echo "Home Page";
        }else{
            echo $titulo;
        }
    ?>
    </title>
</head>

<header>
    <?php
    $search =  '<img id="search-icon" src="/YouJob/img/search.png" alt="search">
        <input tyep="search" name="search" id="search" placeholder="Search Here">';
    if (file_exists('index.php')) {
        $search = null;
    } else {
        echo $search;
    }
    ?>
    <section>
        <figure>
            <img src="/YouJob/img/moon.png" alt="">
        </figure>
        <figure>
            <img src="/YouJob/img/notification.png" alt="">
        </figure>
        <figure>
            <a href="/YouJob/HTML/Cadastro.php"><img src="/YouJob/img/perfil.png" alt=""></a>
        </figure>
    </section>
</header>

<aside>
    <div class="sidebar">
        <a href="/YouJob/index.php">
            <img class="side-item logo" src="/YouJob/img/logo.png" alt="">
        </a>
        <img class="side-item menu" src="/YouJob/img/menu.png" alt="">
        <img class="side-item bid" src="/YouJob/img/bid.png" alt="">
        <img class="side-item heart" src="/YouJob/img/heart.png" alt="">
        <img class="side-item star" src="/YouJob/img/star.png" alt="">
        <img class="side-item setting" src="/YouJob/img/setting.png" alt="">
    </div>
</aside>