<?php
$pathinfo = pathinfo(__FILE__);

echo "O nome do arquivo é: " . $pathinfo['filename'];
?>