<?php
    include_once "..\base\header.php";
?>

<style>
    header {
        justify-content: end !important;
    }
</style>

<body>
    <img id="background-home" src="/YouJob/img/background-home.jpg" alt="">

    <main id="Home">
        <section id="inicio">
            <div id="youjob">
                <h1>YouJob</h1>
            </div>
            <div id="descricao">
                <span class="text-animate-1"></span>
                <h2 class="text-animate-2"></h2>

            </div>
            <div class="search-H">
                <input type="search" name="pesquisar" placeholder="Search Here">
                <img class="search-icon" src="/YouJob/img/search.png" alt="">
            </div>
        </section>

        <div class="cards-H">
            <section class="card-H">Pedidos</section>
            <section class="card-H">Perfis</section>
            <section class="card-H">Em Alta!!</section>
            <section class="card-H">Sobre</section>
        </div>

    </main>
    <script src="https://unpkg.com/typed.js@2.1.0/dist/typed.umd.js"></script>

<script>
 var typed2 = new Typed('.text-animate-1', {
    strings: ['um <strong>Serviço</strong> ',],
    typeSpeed: 10,
    backSpeed: 0,
    fadeOut: true,
    loop: true
  });
    

  var typed = new Typed('.text-animate-2', {
    strings: ['à um click de distância'],
    loop: true,
    typeSpeed: 150
  });
</script>


</body>

</html>