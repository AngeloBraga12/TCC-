<?php
    include_once "base\header.php";
?>

<style>
    header {
        justify-content: end !important;
    }
</style>

<body>
    <img id="background-home" src="/YouJob/img/background-home.jpg" alt="">

    <main id="Home">
        <section id="inicio">
            <div id="youjob">
                <h1 class="titulo"></h1>
            </div>
            <div id="descricao">
                <span class="text-animate-1"></span> <br> 
                &nbsp<span class="text-animate-2"></span>

            </div>
            <div class="search-H">
                <input type="search" name="pesquisar" placeholder="Search Here">
                <img class="search-icon" src="/YouJob/img/search.png" alt="">
            </div>
        </section>

        <div class="cards-H">
            <section class="card-H">Pedidos</section>
            <section class="card-H">Perfis</section>
            <section class="card-H">Em Alta!!</section>
            <section class="card-H">Sobre</section>
        </div>

    </main>
    <script src="https://unpkg.com/typed.js@2.1.0/dist/typed.umd.js"></script>

<script>
 var typed2 = new Typed('.text-animate-1', {
    strings: ['um <strong>Serviço</strong> ',],
    typeSpeed: 60,
    backDelay: 0,
    StartDelay: 1500,
    loop: false
  });
    
  var typed2 = new Typed('.text-animate-2', {
    strings: ['a um <strong>Click</strong> de distância. ',],
    typeSpeed: 75,
    backSpeed: 0,
    StartDelay: 50,
    loop: false
  });

  var typed2 = new Typed('.titulo', {
    strings: ['YouJob',],
    typeSpeed: 110,
    backSpeed: 0,
    StartDelay: 0,
    loop: false
  });
  
</script>

</body>

</html>