import React from 'react';
import TypeAnimation from 'react-type-animation';

const MyComponent = () => {
  return (
    <TypeAnimation
      sequence={[
        'This is a type animation', // Types 'This is a type animation'
        1000, // Waits 1s
        'Then it is replaced with', // Types 'Then it is replaced with'
        1000, // Waits 1s
        'TYPE ANIMATION!', // Types 'TYPE ANIMATION!'
        1000, // Waits 1s
        () => {
          console.log('Done!'); // Place optional callbacks in a sequence
        }
      ]}
      wrapper="sp"
      cursor={true}
      repeat={Infinity}
      style={{ fontSize: '2em' }}
    />
  );
};

export default MyComponent;